package com.app.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;

import com.app.domain.MST_User;

public class LoginUserDetails implements UserDetails {
    private final MST_User loginUserForm;

    private final Collection<? extends GrantedAuthority> authorities;

    public LoginUserDetails(MST_User loginUserForm) {
        this.loginUserForm = loginUserForm;
        this.authorities = AuthorityUtils.createAuthorityList("ROLE_ADMIN");
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return loginUserForm.getPassword();
    }

    @Override
    public String getUsername() {
        return loginUserForm.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
