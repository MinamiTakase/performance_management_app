package com.app.security;

import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.domain.MST_User;
import com.app.mapper.LoginMapper;

@Service
public class LoginUserDetailsService implements UserDetailsService {

    private final LoginMapper loginMapper;

    public LoginUserDetailsService(LoginMapper loginMapper) {
        this.loginMapper = loginMapper;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<MST_User> loginUserOptional = loginMapper.findByAccount(username);
        return loginUserOptional.map(loginUserForm -> new LoginUserDetails(loginUserForm))
                .orElseThrow(() -> new UsernameNotFoundException("not found"));
    }
}
