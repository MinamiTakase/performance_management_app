package com.app.mapper;

import java.util.Map;
import java.util.Optional;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.app.domain.MST_User;

@Repository
public class LoginMapper {
    private NamedParameterJdbcTemplate template;

    public LoginMapper(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.template = namedParameterJdbcTemplate;
    }

    /**
     * ログインユーザ取得処理
     * 
     * @param username
     * @return Optional<LoginUserForm>
     */
    public Optional<MST_User> findByAccount(String username) {
        StringBuilder sql = new StringBuilder();
        sql.append(
                "SELECT "
                        + "account_id as username "
                        + ",password "
                        + "FROM "
                        + "mst_user_tbl "
                        + "WHERE "
                        + "account_id = :username");
        SqlParameterSource prm = new MapSqlParameterSource().addValue("username", username);
        Map<String, Object> result = template.queryForMap(sql.toString(), prm);
        MST_User form = new MST_User();
        form.setUsername((String) result.get("username"));
        form.setPassword((String) result.get("password"));
        return Optional.ofNullable(form);
    }
}
